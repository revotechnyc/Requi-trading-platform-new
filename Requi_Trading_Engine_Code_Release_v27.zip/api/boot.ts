import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { createOAuthCallbackHandler } from "./kimi/auth";
import { ensureSchema } from "./lib/ensure-schema";
import { ensureGovernanceReady } from "./governance/runtime";
import { ensureSystemCheckLoop } from "./systemcheck/service";
import { ensureTrailingLoop } from "./engine/trailing";
import { ensureUniverseLoop } from "./engine/universe";
import { Paths } from "@contracts/constants";

const app = new Hono<{ Bindings: HttpBindings }>();

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.get(Paths.oauthCallback, createOAuthCallbackHandler());
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  await ensureSchema(); // fresh databases work on first boot — live stream, alerts, limits
  await ensureGovernanceReady(); // registry sync + signed genesis governance package if none active
  ensureSystemCheckLoop(); // pre-open (09:00 ET) + post-close (16:15 ET) health runs, Mon–Fri
  ensureTrailingLoop(); // 5s protective-exit cycle during market hours — flat stop, 2.5×ATR trail, safety flatten
  ensureUniverseLoop(); // 60s engine heartbeat — feed refresh → monitor evaluation → auto-universe cycles
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
