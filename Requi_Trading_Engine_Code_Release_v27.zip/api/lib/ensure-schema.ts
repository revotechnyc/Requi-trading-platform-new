import mysql from "mysql2/promise";
import { env } from "./env";

/**
 * Idempotent boot-time schema guard.
 *
 * Every table the app touches is created with CREATE TABLE IF NOT EXISTS so a
 * fresh database (new deploy, new preview, new developer machine) works on
 * first boot — no manual SQL, no interactive drizzle-kit prompt. Existing
 * tables are never altered or dropped.
 */
const STATEMENTS: string[] = [
  `CREATE TABLE IF NOT EXISTS users (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    unionId VARCHAR(255) NOT NULL UNIQUE,
    name VARCHAR(255),
    email VARCHAR(320),
    avatar TEXT,
    role ENUM('user','admin') NOT NULL DEFAULT 'user',
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    lastSignInAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS strategies (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    userId BIGINT UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    source ENUM('TradingView','TrendSpider','Custom') NOT NULL DEFAULT 'Custom',
    asset ENUM('Stocks','Crypto','Options','Futures') NOT NULL DEFAULT 'Stocks',
    status ENUM('Live','Paper','Paused') NOT NULL DEFAULT 'Paper',
    prompt TEXT NOT NULL,
    parsedPlan TEXT,
    accounts INT NOT NULL DEFAULT 0,
    pnl30d DECIMAL(8,2) NOT NULL DEFAULT 0,
    winRate INT NOT NULL DEFAULT 0,
    trades INT NOT NULL DEFAULT 0,
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_strategies_user (userId)
  )`,
  `CREATE TABLE IF NOT EXISTS broker_accounts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    userId BIGINT UNSIGNED NOT NULL,
    broker VARCHAR(100) NOT NULL,
    label VARCHAR(255) NOT NULL,
    type ENUM('Live','Paper','IRA','Prop') NOT NULL DEFAULT 'Paper',
    equity DECIMAL(16,2) NOT NULL DEFAULT 0,
    dayPnl DECIMAL(16,2) NOT NULL DEFAULT 0,
    status ENUM('Connected','Syncing','Attention') NOT NULL DEFAULT 'Connected',
    strategies INT NOT NULL DEFAULT 0,
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_broker_accounts_user (userId)
  )`,
  `CREATE TABLE IF NOT EXISTS marketplace_items (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    kind ENUM('Strategy','AI Prompt') NOT NULL,
    asset VARCHAR(50) NOT NULL,
    price INT NOT NULL DEFAULT 0,
    rating DECIMAL(2,1) NOT NULL DEFAULT 4.5,
    sales INT NOT NULL DEFAULT 0,
    return90d DECIMAL(8,2) NOT NULL DEFAULT 0,
    prompt TEXT NOT NULL,
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS support_tickets (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    userId BIGINT UNSIGNED,
    userName VARCHAR(255) NOT NULL,
    userEmail VARCHAR(320) NOT NULL,
    subject VARCHAR(500) NOT NULL,
    description TEXT,
    category ENUM('Billing','Execution','Connections','Strategies','Account') NOT NULL DEFAULT 'Account',
    priority ENUM('Urgent','High','Normal','Low') NOT NULL DEFAULT 'Normal',
    status ENUM('Open','In progress','Waiting on user','Resolved') NOT NULL DEFAULT 'Open',
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS ai_limits (
    userId BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    paperOnly BOOLEAN NOT NULL DEFAULT TRUE,
    maxOrderNotional DECIMAL(14,2) NOT NULL DEFAULT 5000,
    dailyNotionalCap DECIMAL(14,2) NOT NULL DEFAULT 20000,
    dailyTokenCap INT NOT NULL DEFAULT 200000,
    killSwitch BOOLEAN NOT NULL DEFAULT FALSE,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS alerts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    userId BIGINT UNSIGNED NOT NULL,
    type ENUM('OPPORTUNITY','CONFIRMATION_REQUEST','EXECUTION','PROTECTION','POSITION_UPDATE','RISK','NO_TRADE_STATUS','SYSTEM_STATE') NOT NULL,
    priority ENUM('CRITICAL','HIGH','MEDIUM','LOW') NOT NULL,
    title VARCHAR(255) NOT NULL,
    body TEXT,
    symbol VARCHAR(32),
    state VARCHAR(48),
    \`read\` BOOLEAN NOT NULL DEFAULT FALSE,
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_alerts_user (userId)
  )`,
  `CREATE TABLE IF NOT EXISTS run_sessions (
    userId BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    active BOOLEAN NOT NULL DEFAULT FALSE,
    mode VARCHAR(32) NOT NULL DEFAULT 'AUTONOMOUS_PAPER',
    startedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    lastEventAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    arc VARCHAR(24) NOT NULL DEFAULT 'idle',
    symbol VARCHAR(16),
    entry DECIMAL(12,2),
    stop DECIMAL(12,2),
    target DECIMAL(12,2),
    ticketId VARCHAR(24),
    ticks INT NOT NULL DEFAULT 0
  )`,
  `CREATE TABLE IF NOT EXISTS run_events (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    userId BIGINT UNSIGNED NOT NULL,
    phase VARCHAR(20) NOT NULL,
    kind ENUM('info','success','warn','risk','trade') NOT NULL DEFAULT 'info',
    message TEXT NOT NULL,
    symbol VARCHAR(16),
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_run_events_user (userId)
  )`,
  `CREATE TABLE IF NOT EXISTS governance_documents (
    docKey VARCHAR(64) NOT NULL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    version VARCHAR(32) NOT NULL,
    sha256 VARCHAR(64) NOT NULL,
    status ENUM('REGISTERED','AUTHENTICATED','SUPERSEDED') NOT NULL DEFAULT 'REGISTERED',
    registeredAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS order_tickets (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ticketId VARCHAR(40) NOT NULL UNIQUE,
    userId BIGINT UNSIGNED NOT NULL,
    strategy VARCHAR(64) NOT NULL,
    broker VARCHAR(24) NOT NULL DEFAULT 'PAPER',
    effectiveBroker VARCHAR(24),
    accountId VARCHAR(64),
    symbol VARCHAR(16) NOT NULL,
    side ENUM('BUY','SELL') NOT NULL,
    quantity INT NOT NULL,
    orderType ENUM('MKT','LMT','STP','STP_LMT','TRAIL') NOT NULL DEFAULT 'LMT',
    limitPrice DECIMAL(12,2),
    stopPrice DECIMAL(12,2),
    tif VARCHAR(8) NOT NULL DEFAULT 'DAY',
    state VARCHAR(32) NOT NULL DEFAULT 'CREATED',
    entry DECIMAL(12,2),
    stop DECIMAL(12,2),
    target DECIMAL(12,2),
    maxLoss DECIMAL(12,2),
    rr DECIMAL(6,2),
    idempotencyKey VARCHAR(64) NOT NULL,
    brokerOrderId VARCHAR(64),
    filledQuantity INT,
    averageFillPrice DECIMAL(12,2),
    expiresAt TIMESTAMP NOT NULL,
    confirmedAt TIMESTAMP NULL,
    submittedAt TIMESTAMP NULL,
    lastMessage VARCHAR(500),
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_tickets_user (userId),
    UNIQUE INDEX uq_tickets_idem (userId, idempotencyKey)
  )`,
  `CREATE TABLE IF NOT EXISTS governance_packages (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    version VARCHAR(32) NOT NULL,
    hash VARCHAR(64) NOT NULL,
    signature VARCHAR(64) NOT NULL,
    status ENUM('STAGED','ACTIVE','ROLLED_BACK','REJECTED') NOT NULL DEFAULT 'STAGED',
    artifact TEXT NOT NULL,
    report TEXT NOT NULL,
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    activatedAt TIMESTAMP NULL
  )`,
  `CREATE TABLE IF NOT EXISTS chat_messages (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    userId BIGINT UNSIGNED NOT NULL,
    role VARCHAR(16) NOT NULL,
    content TEXT NOT NULL,
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_chat_user (userId, createdAt)
  )`,
  `CREATE TABLE IF NOT EXISTS trade_outcomes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    userId BIGINT UNSIGNED NOT NULL,
    symbol VARCHAR(16) NOT NULL,
    strategyId VARCHAR(64) NOT NULL,
    variantId VARCHAR(64),
    source ENUM('BACKTEST','SIMULATION','PAPER','LIVE') NOT NULL,
    entry DECIMAL(12,4),
    exitPrice DECIMAL(12,4),
    qty INT,
    pnl DECIMAL(12,2),
    rMultiple DECIMAL(8,3),
    exitReason VARCHAR(32),
    lesson VARCHAR(255),
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_outcomes_user (userId, strategyId)
  )`,
  `CREATE TABLE IF NOT EXISTS system_check_reports (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    triggerType VARCHAR(24) NOT NULL,
    overall VARCHAR(8) NOT NULL,
    okCount INT NOT NULL DEFAULT 0,
    warnCount INT NOT NULL DEFAULT 0,
    failCount INT NOT NULL DEFAULT 0,
    checksJson TEXT NOT NULL,
    aiDiagnosis TEXT,
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS positions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    userId BIGINT UNSIGNED NOT NULL,
    symbol VARCHAR(16) NOT NULL,
    quantity INT NOT NULL,
    avgEntry DECIMAL(12,4) NOT NULL,
    sourceTicketId VARCHAR(64),
    status ENUM('OPEN','CLOSED') NOT NULL DEFAULT 'OPEN',
    openedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    closedAt TIMESTAMP NULL,
    exitPrice DECIMAL(12,4),
    realizedPnl DECIMAL(12,2),
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_positions_user (userId, status)
  )`,
];

/** Column-level guards for tables that predate newer features. */
const COLUMN_STATEMENTS: string[] = [
  // RBAC access level for the governance boundary (USER by default)
  `ALTER TABLE users ADD COLUMN govRole VARCHAR(32) NOT NULL DEFAULT 'USER' AFTER role`,
  // Auto-execute preference (default OFF — confirmation still required unless enabled)
  `ALTER TABLE users ADD COLUMN autoExecute TINYINT(1) NOT NULL DEFAULT 0 AFTER govRole`,
  // Audit marker on tickets executed via the auto path
  `ALTER TABLE order_tickets ADD COLUMN autoExecuted TINYINT(1) NOT NULL DEFAULT 0 AFTER accountId`,
  // Trailing-stop state on positions (trailing module)
  `ALTER TABLE positions ADD COLUMN stopPrice DECIMAL(12,4) NULL AFTER realizedPnl`,
  `ALTER TABLE positions ADD COLUMN t1Price DECIMAL(12,4) NULL AFTER stopPrice`,
  `ALTER TABLE positions ADD COLUMN highestPrice DECIMAL(12,4) NULL AFTER t1Price`,
  `ALTER TABLE positions ADD COLUMN trailPrice DECIMAL(12,4) NULL AFTER highestPrice`,
  `ALTER TABLE positions ADD COLUMN trailArmed TINYINT(1) NOT NULL DEFAULT 0 AFTER trailPrice`,
  `ALTER TABLE positions ADD COLUMN scaleStage INT NOT NULL DEFAULT 0 AFTER trailArmed`,
  `ALTER TABLE positions ADD COLUMN closedBy VARCHAR(24) NULL AFTER scaleStage`,
  // Final autonomous update: stop modes, T2 scale-outs, overrides, disaster stop
  `ALTER TABLE users ADD COLUMN stopMode VARCHAR(16) NOT NULL DEFAULT 'CLASSIC' AFTER autoExecute`,
  `ALTER TABLE order_tickets ADD COLUMN target2 DECIMAL(12,2) NULL AFTER target`,
  `ALTER TABLE positions ADD COLUMN t2Price DECIMAL(12,4) NULL AFTER closedBy`,
  `ALTER TABLE positions ADD COLUMN overrideMode VARCHAR(16) NULL AFTER t2Price`,
  `ALTER TABLE positions ADD COLUMN disasterOrderId VARCHAR(64) NULL AFTER overrideMode`,
  `ALTER TABLE positions ADD COLUMN disasterPrice DECIMAL(12,4) NULL AFTER disasterOrderId`,
  // Auto-universe engine (Strategy Spec §3 stages 1–2): bot-built watchlist, default OFF
  `ALTER TABLE users ADD COLUMN autoUniverse TINYINT(1) NOT NULL DEFAULT 0 AFTER stopMode`,
  `ALTER TABLE users ADD COLUMN autoUniverseMax INT NOT NULL DEFAULT 5 AFTER autoUniverse`,
];

/** Tables that carry a userId foreign reference, for duplicate-user merges. */
const USER_ID_TABLES = ["strategies", "broker_accounts", "alerts", "run_events", "run_sessions", "ai_limits", "support_tickets", "chat_messages", "trade_outcomes", "positions"];

let ensured = false;

export async function ensureSchema() {
  if (ensured) return;
  const conn = await mysql.createConnection(env.databaseUrl);
  try {
    for (const sql of STATEMENTS) {
      await conn.query(sql);
    }
    for (const sql of COLUMN_STATEMENTS) {
      try {
        await conn.query(sql);
      } catch (e) {
        // duplicate column = already applied; anything else is worth logging
        if (!(e as Error).message.includes("Duplicate column")) {
          console.warn("[db] column guard skipped:", (e as Error).message);
        }
      }
    }
    ensured = true;
    console.log(`[db] schema ensured (${STATEMENTS.length} tables)`);

    // Self-heal: merge duplicate users (same unionId) into the oldest row,
    // then enforce the unique constraint the upsert path relies on.
    try {
      const [dups] = await conn.query(
        "SELECT unionId, MIN(id) AS keepId FROM users GROUP BY unionId HAVING COUNT(*) > 1",
      );
      for (const d of dups as Array<{ unionId: string; keepId: number }>) {
        const [rows] = await conn.query("SELECT id FROM users WHERE unionId = ? AND id <> ?", [d.unionId, d.keepId]);
        const dropIds = (rows as Array<{ id: number }>).map((r) => r.id);
        if (dropIds.length === 0) continue;
        for (const table of USER_ID_TABLES) {
          await conn.query(`UPDATE ${table} SET userId = ? WHERE userId IN (${dropIds.join(",")})`, [d.keepId]);
        }
        await conn.query(`DELETE FROM users WHERE id IN (${dropIds.join(",")})`);
      }
      const [idx] = await conn.query("SHOW INDEX FROM users WHERE Column_name = 'unionId'");
      const list = idx as Array<{ Key_name: string; Non_unique: number }>;
      if (list.length === 0) {
        await conn.query("ALTER TABLE users ADD UNIQUE INDEX uq_users_unionId (unionId)");
      } else if (list[0].Non_unique !== 0) {
        await conn.query(`ALTER TABLE users DROP INDEX \`${list[0].Key_name}\`, ADD UNIQUE INDEX uq_users_unionId (unionId)`);
      }
    } catch (e) {
      console.warn("[db] users self-heal skipped:", (e as Error).message);
    }
  } finally {
    await conn.end();
  }
}
