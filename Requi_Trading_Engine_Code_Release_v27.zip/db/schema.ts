import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
  decimal,
  boolean,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  /** Governance RBAC level: USER | OPERATOR | RISK_COMPLIANCE | GOVERNANCE_ADMIN | DEVELOPER */
  govRole: varchar("govRole", { length: 32 }).notNull().default("USER"),
  /** When true, AUTONOMOUS-origin engine proposals execute without the CONFIRM string. Default off. */
  autoExecute: boolean("autoExecute").notNull().default(false),
  stopMode: varchar("stopMode", { length: 16 }).notNull().default("CLASSIC"), // CLASSIC (flat stop → 1R arm → ATR trail) | IMMEDIATE_TRAIL (0.5% trail from entry + moving hard bottom)
  /** When true, the auto-universe engine builds this user's watchlist and starts monitors automatically (Strategy Spec §3 stages 1–2). Default off. */
  autoUniverse: boolean("autoUniverse").notNull().default(false),
  /** Max concurrent auto-universe monitors per user. */
  autoUniverseMax: int("autoUniverseMax").notNull().default(5),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Trading: text-based strategies ─────────────────────────────────────────

export const strategies = mysqlTable("strategies", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  source: mysqlEnum("source", ["TradingView", "TrendSpider", "Custom"]).notNull().default("Custom"),
  asset: mysqlEnum("asset", ["Stocks", "Crypto", "Options", "Futures"]).notNull().default("Stocks"),
  status: mysqlEnum("status", ["Live", "Paper", "Paused"]).notNull().default("Paper"),
  prompt: text("prompt").notNull(), // text-based strategy definition
  parsedPlan: text("parsedPlan"), // JSON string of the parsed execution plan
  accounts: int("accounts").notNull().default(0),
  pnl30d: decimal("pnl30d", { precision: 8, scale: 2 }).notNull().default("0"),
  winRate: int("winRate").notNull().default(0),
  trades: int("trades").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Strategy = typeof strategies.$inferSelect;

// ─── Broker accounts ─────────────────────────────────────────────────────────

export const brokerAccounts = mysqlTable("broker_accounts", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  broker: varchar("broker", { length: 100 }).notNull(),
  label: varchar("label", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["Live", "Paper", "IRA", "Prop"]).notNull().default("Paper"),
  equity: decimal("equity", { precision: 16, scale: 2 }).notNull().default("0"),
  dayPnl: decimal("dayPnl", { precision: 16, scale: 2 }).notNull().default("0"),
  status: mysqlEnum("status", ["Connected", "Syncing", "Attention"]).notNull().default("Connected"),
  strategies: int("strategies").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BrokerAccount = typeof brokerAccounts.$inferSelect;

// ─── Marketplace ─────────────────────────────────────────────────────────────

export const marketplaceItems = mysqlTable("marketplace_items", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  author: varchar("author", { length: 255 }).notNull(),
  kind: mysqlEnum("kind", ["Strategy", "AI Prompt"]).notNull(),
  asset: varchar("asset", { length: 50 }).notNull(),
  price: int("price").notNull().default(0),
  rating: decimal("rating", { precision: 2, scale: 1 }).notNull().default("4.5"),
  sales: int("sales").notNull().default(0),
  return90d: decimal("return90d", { precision: 8, scale: 2 }).notNull().default("0"),
  prompt: text("prompt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MarketplaceItem = typeof marketplaceItems.$inferSelect;

// ─── Support tickets ─────────────────────────────────────────────────────────

export const supportTickets = mysqlTable("support_tickets", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }), // null = logged by owner on behalf of user
  userName: varchar("userName", { length: 255 }).notNull(),
  userEmail: varchar("userEmail", { length: 320 }).notNull(),
  subject: varchar("subject", { length: 500 }).notNull(),
  description: text("description"),
  category: mysqlEnum("category", ["Billing", "Execution", "Connections", "Strategies", "Account"]).notNull().default("Account"),
  priority: mysqlEnum("priority", ["Urgent", "High", "Normal", "Low"]).notNull().default("Normal"),
  status: mysqlEnum("status", ["Open", "In progress", "Waiting on user", "Resolved"]).notNull().default("Open"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SupportTicket = typeof supportTickets.$inferSelect;

// ─── Per-user AI limits / guardrails ─────────────────────────────────────────

export const aiLimits = mysqlTable("ai_limits", {
  userId: bigint("userId", { mode: "number", unsigned: true }).primaryKey(),
  paperOnly: boolean("paperOnly").notNull().default(true),
  maxOrderNotional: decimal("maxOrderNotional", { precision: 14, scale: 2 }).notNull().default("5000"),
  dailyNotionalCap: decimal("dailyNotionalCap", { precision: 14, scale: 2 }).notNull().default("20000"),
  dailyTokenCap: int("dailyTokenCap").notNull().default(200000),
  killSwitch: boolean("killSwitch").notNull().default(false),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type AiLimits = typeof aiLimits.$inferSelect;

// ─── User notifications & alerts ─────────────────────────────────────────────

export const alerts = mysqlTable("alerts", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  type: mysqlEnum("type", [
    "OPPORTUNITY",
    "CONFIRMATION_REQUEST",
    "EXECUTION",
    "PROTECTION",
    "POSITION_UPDATE",
    "RISK",
    "NO_TRADE_STATUS",
    "SYSTEM_STATE",
  ]).notNull(),
  priority: mysqlEnum("priority", ["CRITICAL", "HIGH", "MEDIUM", "LOW"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  body: text("body"),
  symbol: varchar("symbol", { length: 32 }),
  state: varchar("state", { length: 48 }),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Alert = typeof alerts.$inferSelect;

// ─── Autonomous run sessions & live event stream ─────────────────────────────

export const runSessions = mysqlTable("run_sessions", {
  userId: bigint("userId", { mode: "number", unsigned: true })
    .primaryKey()
    .references(() => users.id),
  active: boolean("active").notNull().default(false),
  mode: varchar("mode", { length: 32 }).notNull().default("AUTONOMOUS_PAPER"),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  lastEventAt: timestamp("lastEventAt").defaultNow().notNull(),
  arc: varchar("arc", { length: 24 }).notNull().default("idle"),
  symbol: varchar("symbol", { length: 16 }),
  entry: decimal("entry", { precision: 12, scale: 2 }),
  stop: decimal("stop", { precision: 12, scale: 2 }),
  target: decimal("target", { precision: 12, scale: 2 }),
  ticketId: varchar("ticketId", { length: 24 }),
  ticks: int("ticks").notNull().default(0),
});

export const runEvents = mysqlTable("run_events", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  phase: varchar("phase", { length: 20 }).notNull(),
  kind: mysqlEnum("kind", ["info", "success", "warn", "risk", "trade"]).notNull().default("info"),
  message: text("message").notNull(),
  symbol: varchar("symbol", { length: 16 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type RunEvent = typeof runEvents.$inferSelect;
export type RunSession = typeof runSessions.$inferSelect;

// ─── Private Governance Compiler (server-side only; never sent to clients) ───

export const governanceDocuments = mysqlTable("governance_documents", {
  docKey: varchar("docKey", { length: 64 }).primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  version: varchar("version", { length: 32 }).notNull(),
  sha256: varchar("sha256", { length: 64 }).notNull(),
  status: mysqlEnum("status", ["REGISTERED", "AUTHENTICATED", "SUPERSEDED"]).notNull().default("REGISTERED"),
  registeredAt: timestamp("registeredAt").defaultNow().notNull(),
});

export const governancePackages = mysqlTable("governance_packages", {
  id: serial("id").primaryKey(),
  version: varchar("version", { length: 32 }).notNull(),
  hash: varchar("hash", { length: 64 }).notNull(), // immutable artifact hash
  signature: varchar("signature", { length: 64 }).notNull(), // HMAC over hash
  status: mysqlEnum("status", ["STAGED", "ACTIVE", "ROLLED_BACK", "REJECTED"]).notNull().default("STAGED"),
  artifact: text("artifact").notNull(), // compiled policy packages A–F (JSON, private)
  report: text("report").notNull(), // compilation report: stages, traces, unresolved (JSON, private)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  activatedAt: timestamp("activatedAt"),
});

export type GovernanceDocument = typeof governanceDocuments.$inferSelect;
export type GovernancePackage = typeof governancePackages.$inferSelect;

// ─── Order tickets — the only artifact that may reach a broker ───
// Lifecycle: CREATED → READY_FOR_CONFIRMATION → CONFIRMED → SUBMITTING →
// BROKER_ACK → WORKING → PARTIALLY_FILLED → FILLED → PROTECTED
// Terminal alt states: REJECTED | EXPIRED | CANCELED | FAILED

export const orderTickets = mysqlTable("order_tickets", {
  id: serial("id").primaryKey(),
  ticketId: varchar("ticketId", { length: 40 }).notNull().unique(), // [STRATEGY]-[YYYYMMDD]-[SEQ]
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull().references(() => users.id),
  strategy: varchar("strategy", { length: 64 }).notNull(),
  broker: varchar("broker", { length: 24 }).notNull().default("PAPER"),
  effectiveBroker: varchar("effectiveBroker", { length: 24 }),
  accountId: varchar("accountId", { length: 64 }),
  symbol: varchar("symbol", { length: 16 }).notNull(),
  side: mysqlEnum("side", ["BUY", "SELL"]).notNull(),
  quantity: int("quantity").notNull(),
  orderType: mysqlEnum("orderType", ["MKT", "LMT", "STP", "STP_LMT", "TRAIL"]).notNull().default("LMT"),
  limitPrice: decimal("limitPrice", { precision: 12, scale: 2 }),
  stopPrice: decimal("stopPrice", { precision: 12, scale: 2 }),
  tif: varchar("tif", { length: 8 }).notNull().default("DAY"),
  state: varchar("state", { length: 32 }).notNull().default("CREATED"),
  entry: decimal("entry", { precision: 12, scale: 2 }),
  stop: decimal("stop", { precision: 12, scale: 2 }),
  target: decimal("target", { precision: 12, scale: 2 }),
  target2: decimal("target2", { precision: 12, scale: 2 }), // second scale-out target (engine proposals)
  maxLoss: decimal("maxLoss", { precision: 12, scale: 2 }),
  rr: decimal("rr", { precision: 6, scale: 2 }),
  /** True when executed via the auto-execute path (no CONFIRM string) — audit marker. */
  autoExecuted: boolean("autoExecuted").notNull().default(false),
  idempotencyKey: varchar("idempotencyKey", { length: 64 }).notNull(),
  brokerOrderId: varchar("brokerOrderId", { length: 64 }),
  filledQuantity: int("filledQuantity"),
  averageFillPrice: decimal("averageFillPrice", { precision: 12, scale: 2 }),
  expiresAt: timestamp("expiresAt").notNull(),
  confirmedAt: timestamp("confirmedAt"),
  submittedAt: timestamp("submittedAt"),
  lastMessage: varchar("lastMessage", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type OrderTicket = typeof orderTickets.$inferSelect;

/* ---------- Intelligence: conversation memory ---------- */

export const chatMessages = mysqlTable("chat_messages", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  role: varchar("role", { length: 16 }).notNull(), // 'user' | 'assistant'
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type ChatMessageRow = typeof chatMessages.$inferSelect;

/* ---------- Learning loop: logged trade outcomes ---------- */

export const tradeOutcomes = mysqlTable("trade_outcomes", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  symbol: varchar("symbol", { length: 16 }).notNull(),
  strategyId: varchar("strategyId", { length: 64 }).notNull(),
  variantId: varchar("variantId", { length: 64 }),
  source: mysqlEnum("source", ["BACKTEST", "SIMULATION", "PAPER", "LIVE"]).notNull(),
  entry: decimal("entry", { precision: 12, scale: 4 }),
  exitPrice: decimal("exitPrice", { precision: 12, scale: 4 }),
  qty: int("qty"),
  pnl: decimal("pnl", { precision: 12, scale: 2 }),
  rMultiple: decimal("rMultiple", { precision: 8, scale: 3 }),
  exitReason: varchar("exitReason", { length: 32 }),
  lesson: varchar("lesson", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type TradeOutcome = typeof tradeOutcomes.$inferSelect;

/* ---------- System check module: health reports (owner-facing) ---------- */

export const systemCheckReports = mysqlTable("system_check_reports", {
  id: serial("id").primaryKey(),
  triggerType: varchar("triggerType", { length: 24 }).notNull(), // 'PRE_OPEN' | 'POST_CLOSE' | 'MANUAL'
  overall: varchar("overall", { length: 8 }).notNull(), // 'OK' | 'WARN' | 'FAIL'
  okCount: int("okCount").notNull().default(0),
  warnCount: int("warnCount").notNull().default(0),
  failCount: int("failCount").notNull().default(0),
  checksJson: text("checksJson").notNull(),
  aiDiagnosis: text("aiDiagnosis"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type SystemCheckReport = typeof systemCheckReports.$inferSelect;

/* ---------- Portfolio: positions opened from fills, for P&L ---------- */

export const positions = mysqlTable("positions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  symbol: varchar("symbol", { length: 16 }).notNull(),
  quantity: int("quantity").notNull(),
  avgEntry: decimal("avgEntry", { precision: 12, scale: 4 }).notNull(),
  sourceTicketId: varchar("sourceTicketId", { length: 64 }),
  status: mysqlEnum("status", ["OPEN", "CLOSED"]).notNull().default("OPEN"),
  openedAt: timestamp("openedAt").defaultNow().notNull(),
  closedAt: timestamp("closedAt"),
  exitPrice: decimal("exitPrice", { precision: 12, scale: 4 }),
  realizedPnl: decimal("realizedPnl", { precision: 12, scale: 2 }),
  /* --- trailing-stop state (api/engine/trailing.ts) --- */
  stopPrice: decimal("stopPrice", { precision: 12, scale: 4 }), // original flat stop — governs until the trail arms
  t1Price: decimal("t1Price", { precision: 12, scale: 4 }), // first target — floor reference after scale-outs
  highestPrice: decimal("highestPrice", { precision: 12, scale: 4 }), // highest price since entry
  trailPrice: decimal("trailPrice", { precision: 12, scale: 4 }), // current trail (never moves down)
  trailArmed: boolean("trailArmed").notNull().default(false), // armed once price reaches entry + 1R (CLASSIC) or at entry (IMMEDIATE_TRAIL)
  scaleStage: int("scaleStage").notNull().default(0), // 0 = full size, 1 = after T1 scale-out, 2 = after T2
  closedBy: varchar("closedBy", { length: 24 }), // FLAT_STOP | TRAIL | SAFETY_FLATTEN | MANUAL_FLATTEN | DISASTER_STOP | null (ticket close)
  t2Price: decimal("t2Price", { precision: 12, scale: 4 }), // second target — T2 scale-out trigger
  overrideMode: varchar("overrideMode", { length: 16 }), // null = module-managed | MANUAL = human owns the exit
  disasterOrderId: varchar("disasterOrderId", { length: 64 }), // resting broker-side catastrophe stop (null on paper)
  disasterPrice: decimal("disasterPrice", { precision: 12, scale: 4 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Position = typeof positions.$inferSelect;
