import { useState } from 'react';
import { Globe2, Library, Play, ShieldBan, ShieldCheck } from 'lucide-react';
import { trpc } from '@/providers/trpc';
import { cn } from '@/lib/utils';

const STATUS_STYLE: Record<string, string> = {
  APPROVED: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  BACKTEST_REQUIRED: 'bg-amber-50 text-amber-700 ring-amber-200',
  PAPER_TRADING: 'bg-sky-50 text-sky-700 ring-sky-200',
  CANARY: 'bg-violet-50 text-violet-700 ring-violet-200',
  DRAFT: 'bg-slate-100 text-slate-600 ring-slate-200',
  DISABLED: 'bg-rose-50 text-rose-700 ring-rose-200',
};

const DECISION_STYLE: Record<string, string> = {
  MONITOR: 'text-emerald-600',
  WAIT: 'text-amber-600',
  REJECT: 'text-rose-600',
};

/**
 * UNIVERSE PANEL — the deterministic strategy engine surface.
 * Auto-universe (bot-built watchlist, Strategy Spec §3 stages 1–2) and the
 * 100-strategy registry with the §2 APPROVED-only eligibility gate.
 */
export default function UniversePanel() {
  const utils = trpc.useUtils();
  const [showAll, setShowAll] = useState(false);

  const { data: universe } = trpc.engine.universe.useQuery(undefined, { refetchInterval: 15000 });
  const { data: stats } = trpc.engine.strategyStats.useQuery(undefined, { refetchInterval: 30000 });
  const { data: registry } = trpc.engine.strategies.useQuery(undefined, { refetchInterval: 30000 });

  const setAutoUniverseMut = trpc.engine.setAutoUniverse.useMutation({
    onSettled: () => void utils.engine.universe.invalidate(),
  });
  const scanMut = trpc.engine.universeScan.useMutation({
    onSettled: () => {
      void utils.engine.universe.invalidate();
      void utils.engine.monitors.invalidate();
    },
  });
  const disableMut = trpc.engine.strategyDisable.useMutation({ onSettled: () => void utils.engine.strategies.invalidate() });
  const enableMut = trpc.engine.strategyEnable.useMutation({ onSettled: () => void utils.engine.strategies.invalidate() });

  const pref = universe?.preference;
  const cycle = universe?.lastCycle;
  const rows = showAll ? registry ?? [] : (registry ?? []).filter((r) => r.firstRelease || r.eligible);

  return (
    <section className="glass rounded-2xl p-6">
      {/* ── auto-universe engine ── */}
      <div className="mb-5 flex items-start gap-3">
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-indigo-500 to-sky-500 text-white">
          <Globe2 className="h-4.5 w-4.5" />
        </div>
        <div className="flex-1">
          <h3 className="text-sm font-bold text-slate-900">Auto-universe engine — the bot builds the watchlist</h3>
          <p className="text-xs text-slate-500">
            Seed universe → filter (price ≥ $5 · $20M session dollar volume · rvol ≥ 1.2 · fresh data) → rank → assign APPROVED strategies → start monitors. Exits always stay with the trailing engine.
          </p>
        </div>
        {universe && (
          <span className={cn('rounded-full px-2.5 py-1 text-[10px] font-bold ring-1', universe.marketHours ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' : 'bg-slate-100 text-slate-500 ring-slate-200')}>
            {universe.marketHours ? 'MARKET OPEN' : 'MARKET CLOSED'}
          </span>
        )}
      </div>

      <div className="mb-5 flex flex-wrap items-center gap-2">
        <button
          onClick={() => setAutoUniverseMut.mutate({ enabled: !pref?.enabled })}
          disabled={setAutoUniverseMut.isPending || !pref}
          className={cn(
            'h-9 rounded-lg px-4 text-xs font-bold transition',
            pref?.enabled ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-900 text-white hover:bg-slate-800',
            'disabled:opacity-50',
          )}
        >
          {pref?.enabled ? 'Auto-universe ON — click to pause' : 'Enable auto-universe'}
        </button>
        <button
          onClick={() => scanMut.mutate()}
          disabled={scanMut.isPending}
          className="flex h-9 items-center gap-1.5 rounded-lg bg-sky-600 px-4 text-xs font-bold text-white transition hover:bg-sky-700 disabled:opacity-50"
        >
          <Play className="h-3.5 w-3.5" /> {scanMut.isPending ? 'Scanning…' : 'Run universe scan now'}
        </button>
        {universe && (
          <span className="text-[11px] text-slate-500">
            {universe.seeds} seeds · {universe.trackedFeeds} feeds tracked · max {pref?.maxMonitors ?? 5} concurrent monitors
          </span>
        )}
      </div>

      {/* last cycle candidates */}
      {cycle && (
        <div className="mb-6 overflow-hidden rounded-xl border border-slate-200">
          <div className="border-b border-slate-200 bg-slate-50 px-3 py-2 text-[11px] font-semibold text-slate-600">
            Last cycle {new Date(cycle.ranAt).toLocaleTimeString()} — {cycle.tracked}/{cycle.seeds} tracked · {cycle.filtered} passed filter · {cycle.monitorsStarted.length} monitors started
            {cycle.monitorsStarted.length > 0 && <span className="ml-2 text-emerald-600">→ {cycle.monitorsStarted.join(', ')}</span>}
          </div>
          {cycle.candidates.length === 0 ? (
            <p className="px-3 py-3 text-xs text-slate-400">No candidates passed the universe filter this cycle.</p>
          ) : (
            <table className="w-full text-left text-[11px]">
              <thead className="bg-white text-slate-400">
                <tr>
                  <th className="px-3 py-1.5 font-semibold">Symbol</th>
                  <th className="px-3 py-1.5 font-semibold">Last</th>
                  <th className="px-3 py-1.5 font-semibold">$ Vol</th>
                  <th className="px-3 py-1.5 font-semibold">RVOL</th>
                  <th className="px-3 py-1.5 font-semibold">Strategy</th>
                  <th className="px-3 py-1.5 font-semibold">Decision</th>
                  <th className="px-3 py-1.5 font-semibold">Reason</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white/60">
                {cycle.candidates.map((c) => (
                  <tr key={c.symbol}>
                    <td className="px-3 py-1.5 font-bold text-slate-800">{c.symbol}</td>
                    <td className="px-3 py-1.5 text-slate-600">${c.last.toFixed(2)}</td>
                    <td className="px-3 py-1.5 text-slate-600">{(c.sessionDollarVolume / 1e6).toFixed(0)}M</td>
                    <td className="px-3 py-1.5 text-slate-600">{c.rvol ?? '—'}</td>
                    <td className="px-3 py-1.5 font-semibold text-slate-700">{c.assignedStrategy ?? '—'}</td>
                    <td className={cn('px-3 py-1.5 font-bold', DECISION_STYLE[c.decision])}>{c.decision}</td>
                    <td className="max-w-[280px] truncate px-3 py-1.5 text-slate-500" title={c.reason}>{c.reason}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* ── strategy registry ── */}
      <div className="mb-4 flex items-start gap-3">
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-slate-700 to-slate-900 text-white">
          <Library className="h-4.5 w-4.5" />
        </div>
        <div className="flex-1">
          <h3 className="text-sm font-bold text-slate-900">Strategy registry — 100 strategies embedded (Spec v1.0)</h3>
          <p className="text-xs text-slate-500">
            Only APPROVED strategies with an executable mapping may trade autonomously (§2). Operator kill is the only runtime status change; promotion ships through the §14 evidence chain + versioned release.
          </p>
        </div>
      </div>

      {stats && (
        <div className="mb-4 flex flex-wrap gap-2 text-[10px] font-bold">
          <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-emerald-700 ring-1 ring-emerald-200">{stats.eligible} ELIGIBLE</span>
          <span className="rounded-full bg-emerald-50/60 px-2.5 py-1 text-emerald-700 ring-1 ring-emerald-200">{stats.approved} APPROVED</span>
          <span className="rounded-full bg-amber-50 px-2.5 py-1 text-amber-700 ring-1 ring-amber-200">{stats.backtestRequired} BACKTEST_REQUIRED</span>
          <span className="rounded-full bg-slate-100 px-2.5 py-1 text-slate-600 ring-1 ring-slate-200">{stats.draft} DRAFT</span>
          <span className="rounded-full bg-rose-50 px-2.5 py-1 text-rose-700 ring-1 ring-rose-200">{stats.disabled} DISABLED</span>
          <span className="rounded-full bg-sky-50 px-2.5 py-1 text-sky-700 ring-1 ring-sky-200">{stats.firstRelease} FIRST RELEASE</span>
        </div>
      )}

      <div className="overflow-hidden rounded-xl border border-slate-200">
        <table className="w-full text-left text-[11px]">
          <thead className="bg-slate-50 text-slate-400">
            <tr>
              <th className="px-3 py-2 font-semibold">ID</th>
              <th className="px-3 py-2 font-semibold">Strategy</th>
              <th className="px-3 py-2 font-semibold">Dir</th>
              <th className="px-3 py-2 font-semibold">TF</th>
              <th className="px-3 py-2 font-semibold">Status</th>
              <th className="px-3 py-2 font-semibold">Hash</th>
              <th className="px-3 py-2 font-semibold"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 bg-white/60">
            {rows.map((r) => (
              <tr key={r.strategyId} className={cn(r.eligible && 'bg-emerald-50/40')}>
                <td className="px-3 py-1.5 font-mono font-bold text-slate-800">
                  {r.strategyId}
                  {r.firstRelease && <span className="ml-1.5 rounded bg-sky-100 px-1 py-0.5 text-[9px] font-bold text-sky-700">1ST</span>}
                </td>
                <td className="px-3 py-1.5 text-slate-700">{r.name}</td>
                <td className={cn('px-3 py-1.5 font-bold', r.direction === 'LONG' ? 'text-emerald-600' : 'text-rose-600')}>{r.direction}</td>
                <td className="px-3 py-1.5 text-slate-500">{r.timeframe}</td>
                <td className="px-3 py-1.5">
                  <span className={cn('rounded-full px-2 py-0.5 text-[10px] font-bold ring-1', STATUS_STYLE[r.status])}>{r.status}</span>
                </td>
                <td className="px-3 py-1.5 font-mono text-[10px] text-slate-400" title="Config hash (§10)">{r.hash}</td>
                <td className="px-3 py-1.5 text-right">
                  {r.status === 'DISABLED' ? (
                    <button onClick={() => enableMut.mutate({ id: r.strategyId })} className="text-emerald-600 hover:text-emerald-700" title="Restore to library status">
                      <ShieldCheck className="h-3.5 w-3.5" />
                    </button>
                  ) : (
                    <button onClick={() => disableMut.mutate({ id: r.strategyId })} className="text-slate-300 hover:text-rose-500" title="Operator kill — DISABLE">
                      <ShieldBan className="h-3.5 w-3.5" />
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <button onClick={() => setShowAll((v) => !v)} className="mt-2 text-[11px] font-semibold text-sky-600 hover:text-sky-700">
        {showAll ? 'Show first-release + eligible only' : `Show all ${registry?.length ?? 100} strategies`}
      </button>
    </section>
  );
}
