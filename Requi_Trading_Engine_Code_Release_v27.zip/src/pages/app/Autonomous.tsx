import { useState } from 'react';
import {
  Bot, ShieldCheck, Cpu, GitBranch, Landmark, Scale, Radar, Power,
  CheckCircle2, XCircle, ArrowRight, AlertTriangle, Lock, Activity, Zap, FileCode2, Bell,
} from 'lucide-react';
import { trpc } from '@/providers/trpc';
import { Badge, PageHeader, StatCard } from './owner/shared';
import RunConsole from '@/components/RunConsole';
import DataFeedPanel from '@/components/DataFeedPanel';
import EnginePanel from '@/components/EnginePanel';
import UniversePanel from '@/components/UniversePanel';
import OrdersPanel from '@/components/OrdersPanel';
import LiveStream from '@/components/LiveStream';
import DemoReplay from '@/components/DemoReplay';
import { cn } from '@/lib/utils';
import {
  AI_MAY, AI_MUST_NOT, TRADE_INTENT_CODE, EVENT_PIPELINE, OPERATING_FREQUENCIES,
  ORDER_STATES, ORDER_STATE_EXITS, CAPITAL_STEPS, BROKER_NATIVE_PROTECTIONS,
  SYNTHETIC_PROTECTIONS, TRAILING_RULES, STRATEGY_FAMILIES, STRATEGY_CONTRACT_SUMMARY,
  KILL_SWITCH_TRIGGERS, INVARIANTS_SUMMARY, EVENT_BUS_SUMMARY,
  AUTONOMY_MODES, CORE_LOOP, TRANSIENT_NO_TRADE, STRUCTURAL_NO_TRADE, MCP_DATA_TYPES,
  DATA_MODES, DATA_QUALITY_GRADES, FILL_MODELS, CONFIRMATION_MODES, ORDER_FLOW,
  POST_ENTRY_MAY, POST_ENTRY_MAY_NOT, STRATEGY_LIFECYCLE, CIRCUIT_BREAKERS, HARD_LIMITS,
  ALERT_CHANNELS, ALERT_TYPE_CATALOG, UI_STATES, UX_RULES,
} from '@/lib/raits-data';

function Section({ icon: Icon, title, sub, children }: {
  icon: React.ComponentType<{ className?: string }>;
  title: string; sub?: string; children: React.ReactNode;
}) {
  return (
    <section className="glass rounded-2xl p-6">
      <div className="mb-5 flex items-start gap-3">
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-royal-500 to-teal-500 text-white">
          <Icon className="h-4.5 w-4.5" />
        </div>
        <div>
          <h2 className="text-base font-bold text-slate-900">{title}</h2>
          {sub && <p className="mt-0.5 text-xs text-slate-500">{sub}</p>}
        </div>
      </div>
      {children}
    </section>
  );
}

const brokerTone = (s: string) => (s === 'BLOCKED' ? 'red' : s === 'ELIGIBLE' ? 'teal' : 'amber') as 'red' | 'teal' | 'amber';
const capMark = (ok: boolean) =>
  ok ? <CheckCircle2 className="h-3.5 w-3.5 text-teal-600" /> : <XCircle className="h-3.5 w-3.5 text-slate-300" />;

export default function Autonomous() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.autonomous.status.useQuery();
  const { data: gov } = trpc.governance.status.useQuery();
  const killMut = trpc.autonomous.setKillSwitch.useMutation({
    onSuccess: () => utils.autonomous.status.invalidate(),
  });
  const modeMut = trpc.autonomous.setAutonomyMode.useMutation({
    onSuccess: () => utils.autonomous.status.invalidate(),
  });
  const [confirmArm, setConfirmArm] = useState(false);
  const [confirmMode, setConfirmMode] = useState<'SESSION_AUTHORIZATION' | 'CONFIRM_BEFORE_ENTRY'>('SESSION_AUTHORIZATION');

  const killActive = data?.aiLimits.killSwitch ?? false;
  const autonomyMode: 'AUTONOMOUS_PAPER' | 'AUTONOMOUS_LIVE' =
    data?.aiLimits.paperOnly === false ? 'AUTONOMOUS_LIVE' : 'AUTONOMOUS_PAPER';

  return (
    <div className="space-y-6">
      <PageHeader
        kicker="Module · Autonomous Trading"
        title="RAITS — Autonomous Intelligence Trading"
        description="Broker-agnostic, event-driven trading operating system. AI conducts research and strategy selection; deterministic services control market data, capital, execution, protection, reconciliation, and shutdown. The Earnings Swarm runs as one registered strategy family inside RAITS."
        actions={
          <>
            <Badge tone="royal">Master Prompt v2.1</Badge>
            <Badge tone="amber">{data?.mode ?? 'SIMULATION'} — controlled pilot only</Badge>
          </>
        }
      />

      {/* governing maxim */}
      <div className="rounded-2xl border border-royal-500/20 bg-gradient-to-r from-royal-500/[0.06] via-sky-500/[0.05] to-teal-500/[0.06] px-6 py-4">
        <p className="text-sm font-semibold text-slate-900">
          Governing maxim: <span className="text-gradient">capital preservation, lawful access, deterministic risk control, account truth, evidence integrity, and broker compliance</span>{' '}
          hold absolute veto authority over alpha, automation, speed, and model confidence.
        </p>
      </div>

      {/* signed governance package status */}
      <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-900/8 bg-slate-900/[0.02] px-5 py-3.5">
        <Lock className="h-4 w-4 text-teal-600" />
        {gov?.activePackage ? (
          <>
            <p className="text-xs font-semibold text-slate-900">
              Operating under signed governance package <span className="font-mono">{gov.activePackage.version}</span>
            </p>
            <Badge tone="teal">signature verified · sha256 {gov.activePackage.hashShort}…</Badge>
          </>
        ) : (
          <>
            <p className="text-xs font-semibold text-red-600">No active signed governance package — the autonomous engine cannot start.</p>
            <Badge tone="red">GOVERNANCE_UNAVAILABLE</Badge>
          </>
        )}
        <span className="ml-auto text-[11px] text-slate-400">Compiled privately · executes deterministically · discloses minimally</span>
      </div>

      {/* autonomy mode + start console */}
      <div className="grid gap-4 lg:grid-cols-2">
        <section className="glass rounded-2xl p-6">
          <div className="mb-4 flex items-start gap-3">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-royal-500 to-teal-500 text-white">
              <Power className="h-4.5 w-4.5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Autonomy mode</h2>
              <p className="mt-0.5 text-xs text-slate-500">Persisted to your account — governs every strategy run.</p>
            </div>
          </div>
          <div className="space-y-3">
            {AUTONOMY_MODES.map((m) => {
              const active = autonomyMode === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => !active && modeMut.mutate({ mode: m.id })}
                  disabled={modeMut.isPending}
                  className={cn(
                    'w-full rounded-xl border p-4 text-left transition-all',
                    active
                      ? m.id === 'AUTONOMOUS_PAPER'
                        ? 'border-royal-500/40 bg-royal-500/[0.06] ring-1 ring-royal-500/30'
                        : 'border-red-500/40 bg-red-500/[0.05] ring-1 ring-red-500/30'
                      : 'border-slate-900/8 bg-slate-900/[0.02] hover:border-slate-900/15',
                  )}
                >
                  <div className="mb-2 flex items-center justify-between">
                    <p className="font-mono text-sm font-bold text-slate-900">{m.id}</p>
                    {active && <Badge tone={m.id === 'AUTONOMOUS_PAPER' ? 'royal' : 'red'}>Selected</Badge>}
                  </div>
                  <ul className="space-y-1">
                    {m.points.map((p) => (
                      <li key={p} className="flex items-start gap-2 text-xs text-slate-600">
                        <CheckCircle2 className={cn('mt-0.5 h-3.5 w-3.5 shrink-0', active ? 'text-teal-600' : 'text-slate-300')} /> {p}
                      </li>
                    ))}
                  </ul>
                </button>
              );
            })}
          </div>
          <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
            Live mode additionally requires a connected authorized broker adapter and full pre-trade validation — selection is recorded now as your governance preference; execution services activate when the control plane is connected.
          </p>
        </section>

        {/* RUN_REQUI_AUTONOMY console */}
        <section className="rounded-2xl bg-slate-900 p-6 text-slate-300">
          <div className="mb-4 flex items-center justify-between">
            <p className="font-mono text-xs font-bold uppercase tracking-widest text-sky-300">Start command</p>
            <span className="live-dot bg-teal-400" />
          </div>
          <pre className="overflow-x-auto whitespace-pre-wrap font-mono text-[12px] leading-relaxed">
{`RUN_REQUI_AUTONOMY

Mode:                `}<span className="font-bold text-teal-300">{autonomyMode}</span>{`
Entry Confirmation:  `}<span className="font-bold text-teal-300">{confirmMode}</span>{`
Strategy:            [id@version OR new input]
Account:             [reference]
Capital Allocation:  [amount]
Run Window:          [start/end]
Universe:            [scope]
Data Provider:       ALPHA_VANTAGE_MCP
Data Mode:           `}{autonomyMode === 'AUTONOMOUS_PAPER' ? <span className="font-bold text-teal-300">REALTIME</span> : <span className="text-slate-500">[REALTIME | DELAYED | HISTORICAL]</span>}
          </pre>
          <div className="mt-4 border-t border-white/10 pt-4">
            <p className="mb-2 text-[11px] font-bold uppercase tracking-wide text-slate-400">Entry confirmation mode</p>
            <div className="flex flex-wrap gap-2">
              {CONFIRMATION_MODES.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setConfirmMode(c.id)}
                  title={c.desc}
                  className={cn(
                    'rounded-lg px-3 py-1.5 font-mono text-[11px] font-semibold transition-colors',
                    confirmMode === c.id ? 'bg-teal-500/20 text-teal-300 ring-1 ring-teal-400/40' : 'bg-white/[0.05] text-slate-400 hover:bg-white/10',
                  )}
                >
                  {c.id}
                </button>
              ))}
            </div>
            <p className="mt-3 text-[11px] leading-relaxed text-slate-400">
              Confirmation format: <span className="font-mono font-semibold text-sky-300">CONFIRM ORDER [TICKET_ID]</span> — no confirmation, no execution.
            </p>
          </div>
        </section>
      </div>

      {/* live run stream — console is sticky on desktop so the feed stays visible like a trading terminal */}
      <div className="mb-3 flex items-center gap-3">
        <h2 className="text-base font-bold text-slate-900">Live run stream</h2>
        <p className="text-xs text-slate-500">The loop, as it happens — every scan, decision, fill, and exit, streamed like a chat.</p>
      </div>
      {/* direct child of the page stack so the pin range spans every section below */}
      <div className="z-30 lg:sticky lg:top-[4.75rem]">
        <RunConsole mode={autonomyMode} />
      </div>

      {/* module 0 — live IBKR data feed with indicators */}
      <DataFeedPanel />

      {/* modules 1–6 — strategy engine: triggers, state machine, backtest, simulate, scan, monitor */}
      <EnginePanel />
      <UniversePanel />

      <OrdersPanel />

      <LiveStream />

      {/* demo replay — scripted SIMULATION of the full v2.4 operation (mock data, no orders) */}
      <DemoReplay />

      {/* pipeline stats */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard icon={Zap} label="Events processed today" value={(data?.pipeline.eventsToday ?? 0).toLocaleString()} sub={`${data?.pipeline.materialEvents ?? 0} passed the materiality filter`} />
        <StatCard icon={FileCode2} label="TradeIntents emitted" value={String(data?.pipeline.tradeIntents ?? 0)} sub={`${data?.pipeline.approved ?? 0} approved · ${data?.pipeline.blocked ?? 0} blocked · ${data?.pipeline.awaitingHuman ?? 0} awaiting human`} />
        <StatCard icon={GitBranch} label="Registered strategies" value={String(data?.pipeline.registeredStrategies ?? 0)} sub="Across 4 strategy families" />
        <StatCard icon={Activity} label="System services" value={`${data?.pipeline.services.healthy ?? 0}/${data?.pipeline.services.total ?? 30}`} sub="All services healthy" />
      </div>

      {/* continuous operating loop + rescan engine */}
      <Section icon={Radar} title="Core operating model — continuous autonomous loop" sub="SCAN → EVALUATE → DECIDE → EXECUTE → MONITOR → EXIT → REPEAT. The system never stops scanning; cash is always a valid decision.">
        <div className="mb-5 flex flex-wrap items-center gap-2">
          {CORE_LOOP.map((s) => (
            <div key={s} className="flex items-center gap-2">
              <span className={cn(
                'rounded-lg px-3 py-1.5 font-mono text-[11px] font-bold',
                s === 'EXIT' ? 'bg-teal-600/10 text-teal-700' : 'border border-royal-500/20 bg-royal-500/[0.06] text-royal-600',
              )}>{s}</span>
              <ArrowRight className="h-3.5 w-3.5 text-slate-400" />
            </div>
          ))}
          <span className="rounded-lg bg-slate-900 px-3 py-1.5 font-mono text-[11px] font-bold text-sky-300">↺ REPEAT</span>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-xl bg-sky-500/[0.05] p-4">
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-sky-700">Transient no-trade → keep monitoring</p>
            <ul className="space-y-1.5">
              {TRANSIENT_NO_TRADE.map((x) => (
                <li key={x} className="flex items-start gap-2 text-sm text-slate-700">
                  <Activity className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sky-600" /> {x}
                </li>
              ))}
            </ul>
            <p className="mt-3 text-xs text-slate-500">Event-triggered re-evaluation until trade found, market closes, system halts, or the user stops.</p>
          </div>
          <div className="rounded-xl bg-red-600/[0.04] p-4">
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-red-600">Structural no-trade → block + define reset</p>
            <ul className="space-y-1.5">
              {STRUCTURAL_NO_TRADE.map((x) => (
                <li key={x} className="flex items-start gap-2 text-sm text-slate-700">
                  <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-red-500" /> {x}
                </li>
              ))}
            </ul>
            <p className="mt-3 text-xs text-slate-500">Block the trade, define the reset condition, and continue scanning other assets.</p>
          </div>
        </div>
      </Section>

      {/* 1. intelligence vs execution */}
      <Section icon={Bot} title="Intelligence is separated from execution" sub="The language model never touches the broker. It emits a constrained TradeIntent; deterministic services validate, size, approve, transmit, monitor, and reconcile.">
        <div className="grid gap-4 lg:grid-cols-3">
          <div className="rounded-xl bg-teal-600/[0.05] p-4">
            <p className="mb-3 text-xs font-bold uppercase tracking-wide text-teal-700">The AI may</p>
            <ul className="space-y-2">
              {AI_MAY.map((x) => (
                <li key={x} className="flex items-start gap-2 text-sm text-slate-700">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-teal-600" /> {x}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-xl bg-red-600/[0.04] p-4">
            <p className="mb-3 text-xs font-bold uppercase tracking-wide text-red-600">The AI must never</p>
            <ul className="space-y-2">
              {AI_MUST_NOT.map((x) => (
                <li key={x} className="flex items-start gap-2 text-sm text-slate-700">
                  <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-500" /> {x}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-xl bg-slate-900 p-4">
            <p className="mb-3 text-xs font-bold uppercase tracking-wide text-sky-300">Minimum-disclosure decision — the only output</p>
            <pre className="overflow-x-auto whitespace-pre-wrap font-mono text-[11px] leading-relaxed text-slate-300">{TRADE_INTENT_CODE}</pre>
          </div>
        </div>
      </Section>

      {/* 2. event-driven pipeline */}
      <Section icon={Radar} title="Event-driven data plane" sub="No five-second universal polling — a one-cent tick never triggers an AI judgment. A volatility break, halt, earnings release, or material headline does.">
        <div className="mb-5 flex flex-wrap items-center gap-2">
          {EVENT_PIPELINE.map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <span className="rounded-lg border border-royal-500/20 bg-royal-500/[0.06] px-3 py-1.5 text-xs font-semibold text-royal-600">{s}</span>
              {i < EVENT_PIPELINE.length - 1 && <ArrowRight className="h-3.5 w-3.5 text-slate-400" />}
            </div>
          ))}
        </div>
        <div className="overflow-x-auto rounded-xl border border-slate-900/5">
          <table className="w-full min-w-[520px] text-sm">
            <thead>
              <tr className="border-b border-slate-900/5 text-left text-[11px] uppercase tracking-wide text-slate-500">
                <th className="px-5 py-2.5 font-medium">Function</th>
                <th className="px-5 py-2.5 font-medium">Recommended method</th>
              </tr>
            </thead>
            <tbody>
              {OPERATING_FREQUENCIES.map((r) => (
                <tr key={r.fn} className="border-b border-slate-900/[0.04] last:border-0">
                  <td className="px-5 py-2.5 font-medium text-slate-700">{r.fn}</td>
                  <td className="px-5 py-2.5 text-slate-500">{r.method}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      {/* 3. broker capability contract */}
      <Section icon={Landmark} title="Broker capability contract" sub="Only officially authorized broker interfaces. No reverse-engineered endpoints, no browser automation, no stored brokerage passwords. Unsupported functionality returns a typed rejection — never a silent emulation.">
        <div className="mb-4 flex items-start gap-2 rounded-xl border border-red-600/15 bg-red-600/[0.04] px-4 py-3">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
          <p className="text-xs leading-relaxed text-slate-700">
            <span className="font-semibold text-red-600">Broker reality:</span> Robinhood's published trading API covers <span className="font-semibold">cryptocurrency only</span>, and trading APIs may not connect to a Robinhood brokerage account without written authorization. Autonomous Robinhood equity or options execution is <span className="font-semibold text-red-600">BLOCKED</span> unless documented authorization and a supported interface are granted.
          </p>
        </div>
        {isLoading && <p className="py-6 text-center text-sm text-slate-500">Loading broker capability matrix…</p>}
        <div className="grid gap-4 lg:grid-cols-2">
          {(data?.brokers ?? []).map((b) => (
            <div key={b.name} className={cn('rounded-xl border p-5', b.status === 'BLOCKED' ? 'border-red-600/20 bg-red-600/[0.03]' : 'border-slate-900/8 bg-slate-900/[0.02]')}>
              <div className="mb-2 flex items-center justify-between">
                <p className="font-bold text-slate-900">{b.name}</p>
                <Badge tone={brokerTone(b.status)}>{b.status}</Badge>
              </div>
              <p className="mb-4 text-xs leading-relaxed text-slate-500">{b.note}</p>
              <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
                <div className="col-span-2 text-slate-600"><span className="font-semibold text-slate-700">Assets:</span> {b.capabilities.assetClasses}</div>
                <span className="flex items-center gap-1.5 text-slate-600">{capMark(b.capabilities.streaming)} Streaming</span>
                <span className="flex items-center gap-1.5 text-slate-600">{capMark(b.capabilities.options)} Options</span>
                <span className="flex items-center gap-1.5 text-slate-600">{capMark(b.capabilities.orderPreview)} Order preview</span>
                <span className="flex items-center gap-1.5 text-slate-600">{capMark(b.capabilities.bracketOco)} Bracket / OCO</span>
                <span className="flex items-center gap-1.5 text-slate-600">{capMark(b.capabilities.trailingStop)} Trailing stop</span>
                <span className="flex items-center gap-1.5 text-slate-600">{capMark(b.capabilities.extendedHours)} Extended hours</span>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* alpha vantage mcp + paper execution */}
      <Section icon={Zap} title="Alpha Vantage MCP — data plane (paper mode)" sub="DATA ONLY — never execution, never a broker, never the simulator. Connection failure blocks the system.">
        <div className="grid gap-4 lg:grid-cols-3">
          <div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Required data types</p>
            <ul className="space-y-1.5">
              {MCP_DATA_TYPES.map((x) => (
                <li key={x} className="flex items-start gap-2 text-sm text-slate-700">
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-teal-600" /> {x}
                </li>
              ))}
            </ul>
            <p className="mt-3 text-xs leading-relaxed text-slate-500">
              Connection requires an MCP endpoint, OAuth or secure API-key backend, <span className="font-mono">tools/list</span> validation, and a rate-limit manager (cache, batch, dedupe, backoff — never over-poll, never treat delayed data as real-time).
            </p>
          </div>
          <div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Data modes</p>
            <div className="space-y-2">
              {DATA_MODES.map((d) => (
                <div key={d.mode} className="flex items-center justify-between rounded-lg bg-slate-900/[0.03] px-3 py-2">
                  <span className="font-mono text-xs font-bold text-slate-900">{d.mode}</span>
                  <Badge tone={d.tone}>{d.rule}</Badge>
                </div>
              ))}
            </div>
            <p className="mb-2 mt-4 text-xs font-bold uppercase tracking-wide text-slate-500">Data quality grades — below required → block trade</p>
            <div className="grid grid-cols-2 gap-2">
              {DATA_QUALITY_GRADES.map((g) => (
                <div key={g.grade} className="rounded-lg border border-slate-900/8 bg-white px-3 py-2">
                  <span className="font-mono text-sm font-bold text-royal-600">{g.grade}</span>
                  <p className="text-[11px] leading-snug text-slate-500">{g.desc}</p>
                </div>
              ))}
            </div>
          </div>
          <div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Paper execution engine — fill models</p>
            <div className="space-y-2">
              {FILL_MODELS.map((f) => (
                <div key={f.type} className="rounded-lg bg-slate-900/[0.03] px-3 py-2">
                  <p className="font-mono text-xs font-bold text-slate-900">{f.type}</p>
                  <p className="text-xs text-slate-500">{f.rule}</p>
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs leading-relaxed text-slate-500">
              The simulator handles <span className="font-semibold">all</span> execution in paper mode — fills, stops, trailing stops, and P&amp;L. Decisions are event-driven off the event bus; charts render from the data cache at 250–500ms and <span className="font-semibold text-red-600">never drive decisions</span>.
            </p>
          </div>
        </div>
      </Section>

      {/* confirmation + order flow + post-entry */}
      <Section icon={FileCode2} title="Confirmation & order flow" sub="QUALIFIED_TRADE builds a full ticket — symbol, side, quantity, limit, stop, target, trailing stop, EV, and R:R — then revalidates price, risk, and data freshness before submission.">
        <div className="grid gap-4 lg:grid-cols-2">
          <ol className="space-y-2">
            {ORDER_FLOW.map((s, i) => (
              <li key={s} className="flex items-start gap-3">
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md bg-royal-500 font-mono text-[10px] font-bold text-white">{i + 1}</span>
                <span className="pt-0.5 text-sm text-slate-700">{s}</span>
              </li>
            ))}
          </ol>
          <div className="space-y-4">
            <div className="rounded-xl bg-teal-600/[0.05] p-4">
              <p className="mb-2 text-xs font-bold uppercase tracking-wide text-teal-700">Post-entry autonomy — the system may</p>
              <div className="flex flex-wrap gap-1.5">
                {POST_ENTRY_MAY.map((x) => (
                  <span key={x} className="rounded-md bg-white px-2.5 py-1 text-[11px] font-medium text-teal-700 ring-1 ring-teal-600/20">{x}</span>
                ))}
              </div>
            </div>
            <div className="rounded-xl bg-red-600/[0.04] p-4">
              <p className="mb-2 text-xs font-bold uppercase tracking-wide text-red-600">And must never</p>
              <div className="flex flex-wrap gap-1.5">
                {POST_ENTRY_MAY_NOT.map((x) => (
                  <span key={x} className="rounded-md bg-white px-2.5 py-1 text-[11px] font-medium text-red-600 ring-1 ring-red-600/20">{x}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* strategy lifecycle + circuit breakers */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Section icon={GitBranch} title="Strategy lifecycle" sub="No draft state. New strategies run in AUTONOMOUS_PAPER immediately; live eligibility requires passing validation.">
          <div className="flex flex-wrap items-center gap-1.5">
            {STRATEGY_LIFECYCLE.map((s, i) => (
              <div key={s} className="flex items-center gap-1.5">
                <span className={cn(
                  'rounded-md px-2.5 py-1 font-mono text-[10.5px] font-semibold',
                  s === 'ACTIVE' ? 'bg-teal-600/10 text-teal-700' : s === 'SUSPENDED' || s === 'RETIRED' ? 'bg-red-600/[0.07] text-red-600' : 'bg-slate-900/[0.05] text-slate-700',
                )}>{s}</span>
                {i < STRATEGY_LIFECYCLE.length - 1 && <span className="text-slate-300">→</span>}
              </div>
            ))}
          </div>
        </Section>

        <Section icon={AlertTriangle} title="Circuit breakers & hard limits" sub="Violations block the trade — no exceptions.">
          <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Breaker triggers</p>
          <div className="mb-4 flex flex-wrap gap-1.5">
            {CIRCUIT_BREAKERS.triggers.map((t) => (
              <span key={t} className="rounded-md bg-red-600/[0.06] px-2.5 py-1 text-[11px] font-medium text-red-600">{t}</span>
            ))}
          </div>
          <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Actions</p>
          <div className="mb-4 flex flex-wrap gap-1.5">
            {CIRCUIT_BREAKERS.actions.map((t) => (
              <span key={t} className="rounded-md bg-amber-500/[0.08] px-2.5 py-1 text-[11px] font-medium text-amber-700">{t}</span>
            ))}
          </div>
          <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Constitutional hard limits</p>
          <div className="flex flex-wrap gap-1.5">
            {HARD_LIMITS.map((t) => (
              <span key={t} className="rounded-md bg-royal-500/[0.07] px-2.5 py-1 text-[11px] font-medium text-royal-600">{t}</span>
            ))}
          </div>
        </Section>
      </div>

      {/* 4. order state machine */}
      <Section icon={GitBranch} title="Order state machine" sub="Submission is idempotent. On timeout, the broker is queried by client order ID before any retry — a timed-out request is never assumed to have failed.">
        <div className="flex flex-wrap items-center gap-1.5">
          {ORDER_STATES.map((s, i) => (
            <div key={s} className="flex items-center gap-1.5">
              <span className={cn(
                'rounded-md px-2.5 py-1 font-mono text-[10.5px] font-semibold',
                s === 'RECONCILED' ? 'bg-teal-600/10 text-teal-700' : 'bg-slate-900/[0.05] text-slate-700',
              )}>{s}</span>
              {i < ORDER_STATES.length - 1 && <span className="text-slate-300">→</span>}
            </div>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Abort exits:</span>
          {ORDER_STATE_EXITS.map((s) => (
            <span key={s} className="rounded-md bg-red-600/[0.07] px-2.5 py-1 font-mono text-[10.5px] font-semibold text-red-600">{s}</span>
          ))}
        </div>
      </Section>

      {/* 5. capital allocation */}
      <Section icon={Scale} title="Deterministic capital allocation" sub="Quantity comes from the most restrictive constraint — not from conviction. Stress loss, never visible stop distance, sizes overnight and event trades.">
        <div className="grid gap-4 md:grid-cols-2">
          {CAPITAL_STEPS.map((c) => (
            <div key={c.step} className="rounded-xl border border-slate-900/8 bg-slate-900/[0.02] p-5">
              <div className="mb-2 flex items-center gap-2.5">
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-royal-500 text-xs font-bold text-white">{c.step}</span>
                <p className="text-sm font-bold text-slate-900">{c.title}</p>
              </div>
              <p className="text-xs leading-relaxed text-slate-500">{c.note}</p>
            </div>
          ))}
        </div>
        {data && (
          <div className="mt-4 flex flex-wrap items-center gap-2 text-xs">
            <span className="font-semibold uppercase tracking-wide text-slate-500">Your AI limits (live, from database):</span>
            <Badge tone={data.aiLimits.paperOnly ? 'amber' : 'teal'}>{data.aiLimits.paperOnly ? 'Paper only' : 'Live permitted'}</Badge>
            <Badge tone="slate">Max order ${parseFloat(data.aiLimits.maxOrderNotional).toLocaleString()}</Badge>
            <Badge tone="slate">Daily cap ${parseFloat(data.aiLimits.dailyNotionalCap).toLocaleString()}</Badge>
            <Badge tone="slate">{data.aiLimits.dailyTokenCap.toLocaleString()} tokens/day</Badge>
          </div>
        )}
      </Section>

      {/* 6. protection orchestrator */}
      <Section icon={ShieldCheck} title="Protection orchestrator" sub="Broker-native stops are only one layer. RAITS synthesizes the rest — and a stop may tighten but never widen after entry.">
        <div className="grid gap-4 lg:grid-cols-2">
          <div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Broker-native protections</p>
            <div className="flex flex-wrap gap-1.5">
              {BROKER_NATIVE_PROTECTIONS.map((p) => (
                <span key={p} className="rounded-md bg-royal-500/[0.07] px-2.5 py-1 text-[11px] font-medium text-royal-600">{p}</span>
              ))}
            </div>
            <p className="mb-2 mt-5 text-xs font-bold uppercase tracking-wide text-slate-500">Synthetic protections (RAITS-internal)</p>
            <div className="flex flex-wrap gap-1.5">
              {SYNTHETIC_PROTECTIONS.map((p) => (
                <span key={p} className="rounded-md bg-teal-600/[0.07] px-2.5 py-1 text-[11px] font-medium text-teal-700">{p}</span>
              ))}
            </div>
          </div>
          <div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Adaptive trailing-stop policy</p>
            <ul className="space-y-2.5">
              {TRAILING_RULES.map((r) => (
                <li key={r} className="flex items-start gap-2 rounded-lg bg-slate-900/[0.03] px-3 py-2 text-xs leading-relaxed text-slate-700">
                  <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-royal-500" /> {r}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      {/* 7. strategy router */}
      <Section icon={Cpu} title="Strategy-routing intelligence" sub='Never "should I buy this stock?" — always "what opportunity class exists, and which registered strategy best expresses it?"'>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {STRATEGY_FAMILIES.map((f) => (
            <div key={f.name} className="rounded-xl border border-slate-900/8 bg-slate-900/[0.02] p-4">
              <p className="mb-3 text-sm font-bold text-slate-900">{f.name}</p>
              <div className="flex flex-wrap gap-1.5">
                {f.items.map((s) => (
                  <span key={s} className="rounded-md bg-white px-2 py-1 text-[10.5px] font-medium text-slate-600 ring-1 ring-slate-900/5">{s}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs leading-relaxed text-slate-500">
          Every registered strategy carries a machine-readable contract covering {STRATEGY_CONTRACT_SUMMARY}. Contract schemas are compiled into the signed governance package and remain server-side.
        </p>
      </Section>

      {/* 8. kill switches */}
      <Section icon={Power} title="Kill switches" sub="Nine independent scopes. A kill switch cancels safe-to-cancel orders, preserves or replaces necessary exits, blocks new entries, and requires documented recovery.">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {(data?.killSwitches ?? []).map((k) => (
            <div key={k.scope} className="flex items-start gap-3 rounded-xl border border-slate-900/8 bg-slate-900/[0.02] p-4">
              <span className={cn('live-dot mt-1.5', k.scope === 'Full platform' && killActive ? 'bg-red-500' : 'bg-teal-500')} />
              <div>
                <p className="text-sm font-bold text-slate-900">{k.scope}</p>
                <p className="text-xs text-slate-500">{k.detail}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4 flex flex-wrap gap-1.5">
          {KILL_SWITCH_TRIGGERS.map((t) => (
            <span key={t} className="rounded-md bg-red-600/[0.06] px-2.5 py-1 text-[11px] font-medium text-red-600">{t}</span>
          ))}
        </div>
        <div className={cn('mt-5 flex flex-col gap-3 rounded-xl border p-5 sm:flex-row sm:items-center sm:justify-between', killActive ? 'border-red-600/30 bg-red-600/[0.05]' : 'border-slate-900/8 bg-slate-900/[0.02]')}>
          <div>
            <p className="text-sm font-bold text-slate-900">Global kill switch {killActive && <span className="ml-2 text-red-600">— ACTIVE: all new entries blocked</span>}</p>
            <p className="text-xs text-slate-500">Persisted to your account in the database — survives restarts and sessions.</p>
          </div>
          {confirmArm && !killActive ? (
            <div className="flex gap-2">
              <button
                onClick={() => { killMut.mutate({ active: true }); setConfirmArm(false); }}
                className="rounded-lg bg-red-600 px-4 py-2 text-xs font-bold text-white hover:bg-red-700"
              >Confirm activation</button>
              <button onClick={() => setConfirmArm(false)} className="rounded-lg border border-slate-900/10 bg-white px-4 py-2 text-xs font-semibold text-slate-700">Cancel</button>
            </div>
          ) : (
            <button
              onClick={() => (killActive ? killMut.mutate({ active: false }) : setConfirmArm(true))}
              disabled={killMut.isPending}
              className={cn(
                'rounded-lg px-4 py-2 text-xs font-bold transition-colors',
                killActive ? 'bg-teal-600 text-white hover:bg-teal-700' : 'bg-red-600/10 text-red-600 hover:bg-red-600/20',
              )}
            >
              {killActive ? 'Deactivate & resume' : 'Activate kill switch'}
            </button>
          )}
        </div>
      </Section>

      {/* notification & alert system */}
      <Section icon={Bell} title="Notification & alert system" sub="The user must never be unaware of opportunities, order creation, execution, risk events, or system state changes. Live in your topbar bell — every alert is logged to the Decision Monitor and Audit Ledger.">
        <div className="grid gap-5 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Mandatory alert types</p>
            <div className="space-y-2">
              {ALERT_TYPE_CATALOG.map((a) => (
                <div key={a.type} className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg bg-slate-900/[0.03] px-3 py-2">
                  <Badge tone={a.priority === 'CRITICAL' ? 'red' : a.priority === 'HIGH' ? 'royal' : a.priority === 'MEDIUM' ? 'sky' : 'slate'}>{a.priority}</Badge>
                  <span className="font-mono text-[11px] font-bold text-slate-900">{a.display}</span>
                  <span className="text-[11px] text-slate-500">{a.trigger}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Delivery channels</p>
            <div className="mb-4 space-y-2">
              {ALERT_CHANNELS.map((c) => (
                <div key={c.name} className="flex items-center justify-between rounded-lg bg-slate-900/[0.03] px-3 py-2">
                  <span className="text-xs font-medium text-slate-700">{c.name}</span>
                  <Badge tone={c.tier === 'PRIMARY' ? 'teal' : 'slate'}>{c.tier}</Badge>
                </div>
              ))}
            </div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">UX rules</p>
            <ul className="space-y-1.5">
              {UX_RULES.map((r) => (
                <li key={r} className="flex items-start gap-2 text-xs text-slate-600">
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-teal-600" /> {r}
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="mt-5 border-t border-slate-900/5 pt-4">
          <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Visual UI states — always visible</p>
          <div className="flex flex-wrap gap-1.5">
            {UI_STATES.map((s) => (
              <span key={s.state} className="rounded-md bg-slate-900 px-2.5 py-1 font-mono text-[10.5px] font-semibold text-sky-300">
                {s.state} <span className="text-slate-500">· {s.desc}</span>
              </span>
            ))}
          </div>
        </div>
      </Section>

      {/* 9. events + invariants */}
      <Section icon={FileCode2} title="Typed event bus & production invariants" sub="Every event carries a unique ID, correlation and causation IDs, normalized timestamps, sequence, schema version, quality flags, entitlement status, and an integrity checksum.">
        <div className="grid gap-5 lg:grid-cols-2">
          <div className="rounded-xl bg-slate-900 p-5">
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-400">Typed immutable event log</p>
            <p className="text-xs leading-relaxed text-slate-300">{EVENT_BUS_SUMMARY}</p>
          </div>
          <div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Every invariant has an automated test</p>
            <div className="flex items-start gap-2 text-xs leading-relaxed text-slate-700">
              <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-teal-600" />
              <p>{INVARIANTS_SUMMARY}</p>
            </div>
          </div>
        </div>
      </Section>

      {/* final principle */}
      <div className="rounded-2xl border border-teal-600/20 bg-gradient-to-r from-teal-500/[0.06] via-sky-500/[0.05] to-royal-500/[0.06] px-6 py-5 text-center">
        <p className="text-sm leading-relaxed text-slate-700">
          The system does not exist to trade constantly. It exists to <span className="font-semibold text-slate-900">find high-quality opportunities</span>, <span className="font-semibold text-slate-900">execute only when conditions align</span>, <span className="font-semibold text-slate-900">protect capital at all times</span> — and do nothing when conditions are not met.
        </p>
        <p className="mt-1.5 text-sm font-bold text-teal-700">Cash is always a valid decision.</p>
      </div>
    </div>
  );
}
